// do not modify this file. It will be automatically regenerated
// based on the version number saved in 'D:\Work\NLog2\src\NLog\..\..\NLog.version'
using System.Reflection;

[assembly: AssemblyVersion("2.0.0.0")]
