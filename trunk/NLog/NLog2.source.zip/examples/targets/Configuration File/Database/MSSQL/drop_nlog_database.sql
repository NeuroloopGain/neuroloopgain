drop database NLogDatabase
go
exec sp_droplogin 'nloguser'
go
