﻿This project is compiled against binary of NLog.dll v1, but when it executes 
NLog.dll v2 is used via assembly redirection.